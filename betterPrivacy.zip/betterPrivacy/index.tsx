/*
 * BetterPrivacy
 */

import definePlugin, { OptionType } from "@utils/types";
import { DataStore } from "@api/index";
import { definePluginSettings } from "@api/Settings";
import { addContextMenuPatch, removeContextMenuPatch, NavContextMenuPatchCallback } from "@api/ContextMenu";
import { Menu, Forms, Button, TextInput, useState, useEffect } from "@webpack/common";
import { SelectedChannelStore, SelectedGuildStore, ChannelStore, GuildStore, FluxDispatcher } from "@webpack/common";

import "./styles.css";

// --- Storage keys ---
const DS_PIN_HASH = "BetterPrivacy_pinHash";
const DS_PIN_SALT = "BetterPrivacy_pinSalt";
const DS_PROTECTED_USERS = "BetterPrivacy_protectedUsers";
const DS_PROTECTED_SERVERS = "BetterPrivacy_protectedServers";
const DS_LOCKED_TARGETS = "BetterPrivacy_lockedTargets";

export type PrivacyMode = "normal" | "screenshot" | "streamer" | "maximum" | "custom";

let currentMode: PrivacyMode = "normal";
let mutationObserver: MutationObserver | null = null;
let hotkeyListener: ((e: KeyboardEvent) => void) | null = null;

// Panic never writes to settings.store.privacyMode, so your real mode stays
// the same when you toggle panic off again.
let panicActive = false;
let panicPreviousMode: PrivacyMode | null = null;

// --- Per-user / per-server ---
interface ProtectedUserFields { avatar: boolean; username: boolean; messages: boolean; }
interface ProtectedUser { id: string; username: string; fields: ProtectedUserFields; }
interface ProtectedServer { id: string; name: string; }

const EMPTY_USER_FIELDS: ProtectedUserFields = { avatar: false, username: false, messages: false };

let protectedUserCache: ProtectedUser[] = [];
let protectedServerCache: ProtectedServer[] = [];

async function getProtectedUsers(): Promise<ProtectedUser[]> {
    return (await DataStore.get<ProtectedUser[]>(DS_PROTECTED_USERS)) ?? [];
}
async function getProtectedServers(): Promise<ProtectedServer[]> {
    return (await DataStore.get<ProtectedServer[]>(DS_PROTECTED_SERVERS)) ?? [];
}

async function toggleUserField(id: string, username: string, field: keyof ProtectedUserFields) {
    const list = await getProtectedUsers();
    let entry = list.find(u => u.id === id);
    if (!entry) {
        entry = { id, username, fields: { ...EMPTY_USER_FIELDS } };
        list.push(entry);
    }
    entry.fields[field] = !entry.fields[field];
    entry.username = username;

    const stillProtected = Object.values(entry.fields).some(Boolean);
    const finalList = stillProtected ? list : list.filter(u => u.id !== id);

    await DataStore.set(DS_PROTECTED_USERS, finalList);
    protectedUserCache = finalList;
    updateEntityStyles();
}

async function toggleProtectedServer(id: string, name: string) {
    const list = await getProtectedServers();
    const idx = list.findIndex(s => s.id === id);
    if (idx >= 0) list.splice(idx, 1);
    else list.push({ id, name });
    await DataStore.set(DS_PROTECTED_SERVERS, list);
    protectedServerCache = list;
    updateEntityStyles();
}

const MODE_CLASS_PREFIX = "bp-mode-";
const ALL_MODE_CLASSES = ["normal", "screenshot", "streamer", "maximum", "custom"].map(m => MODE_CLASS_PREFIX + m);

function applyModeToDom(mode: PrivacyMode) {
    document.body.classList.remove(...ALL_MODE_CLASSES);
    document.body.classList.add(MODE_CLASS_PREFIX + mode);
    currentMode = mode;
    updateFilterVar();
}

// --- PIN: SHA-256 + random salt ---
async function hashPin(pin: string, saltHex: string): Promise<string> {
    const data = new TextEncoder().encode(saltHex + ":" + pin);
    const digest = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
}
function randomSalt(): string {
    const arr = new Uint8Array(16);
    crypto.getRandomValues(arr);
    return Array.from(arr).map(b => b.toString(16).padStart(2, "0")).join("");
}
async function setPin(pin: string) {
    const salt = randomSalt();
    await DataStore.set(DS_PIN_SALT, salt);
    await DataStore.set(DS_PIN_HASH, await hashPin(pin, salt));
}
async function verifyPin(pin: string): Promise<boolean> {
    const salt = await DataStore.get<string>(DS_PIN_SALT);
    const hash = await DataStore.get<string>(DS_PIN_HASH);
    if (!salt || !hash) return true;
    return (await hashPin(pin, salt)) === hash;
}
async function hasPinConfigured(): Promise<boolean> {
    return !!(await DataStore.get<string>(DS_PIN_HASH));
}

// --- Per-channel / per-server locking ---
// A "target" is a channel (covers DMs, group DMs, guild channels) or a
// guild (cascades to all its channels). Unlocking is session-only.
interface LockedTarget { type: "channel" | "guild"; id: string; name: string; }

let lockedTargetCache: LockedTarget[] = [];
const sessionUnlockedKeys = new Set<string>();

function lockKeyFor(type: "channel" | "guild", id: string) {
    return `${type}:${id}`;
}
async function getLockedTargets(): Promise<LockedTarget[]> {
    return (await DataStore.get<LockedTarget[]>(DS_LOCKED_TARGETS)) ?? [];
}
async function toggleLockedTarget(type: "channel" | "guild", id: string, name: string) {
    const list = await getLockedTargets();
    const idx = list.findIndex(t => t.type === type && t.id === id);
    if (idx >= 0) {
        list.splice(idx, 1);
        sessionUnlockedKeys.delete(lockKeyFor(type, id));
    } else {
        list.push({ type, id, name });
    }
    await DataStore.set(DS_LOCKED_TARGETS, list);
    lockedTargetCache = list;
    updateTargetLockOverlay();
}
function isLocked(type: "channel" | "guild", id: string): boolean {
    return lockedTargetCache.some(t => t.type === type && t.id === id) && !sessionUnlockedKeys.has(lockKeyFor(type, id));
}

// <main> is Discord's semantic content landmark, exists even before any
// messages load.
function findChatPanel(): HTMLElement | null {
    return document.querySelector<HTMLElement>('main[role="main"], main');
}

let targetOverlayEl: HTMLElement | null = null;
let targetOverlayKeyBlocker: ((e: KeyboardEvent) => void) | null = null;
let targetOverlayLockKey: string | null = null;

const LOCK_ICON_SVG = `<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="1.5"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>`;

function updateTargetLockOverlay() {
    const channelId = SelectedChannelStore?.getChannelId?.();
    const guildId = SelectedGuildStore?.getGuildId?.();

    let activeKey: string | null = null;
    let label = "";
    if (channelId && isLocked("channel", channelId)) {
        activeKey = lockKeyFor("channel", channelId);
        label = ChannelStore?.getChannel?.(channelId)?.name || "this chat";
    } else if (guildId && isLocked("guild", guildId)) {
        activeKey = lockKeyFor("guild", guildId);
        label = GuildStore?.getGuild?.(guildId)?.name || "this server";
    }

    if (!activeKey) return removeTargetLockOverlay();

    const panel = findChatPanel();
    if (!panel) return removeTargetLockOverlay();

    const rect = panel.getBoundingClientRect();
    if (rect.width < 50 || rect.height < 50) return removeTargetLockOverlay();

    if (targetOverlayEl && targetOverlayLockKey === activeKey) {
        positionTargetOverlay(panel);
        return;
    }

    removeTargetLockOverlay();
    targetOverlayLockKey = activeKey;

    const overlay = document.createElement("div");
    overlay.className = "bp-lock-overlay bp-lock-overlay-panel";
    overlay.innerHTML = `
        <div class="bp-lock-box">
            <div class="bp-lock-icon">${LOCK_ICON_SVG}</div>
            <div class="bp-lock-title">${label}</div>
            <div class="bp-lock-subtitle">Enter PIN to unlock</div>
            <input type="password" class="bp-lock-input" autocomplete="off" inputmode="numeric" />
            <div class="bp-lock-error" style="display:none;">Incorrect PIN</div>
            <button class="bp-lock-button">Unlock</button>
        </div>
    `;
    document.body.appendChild(overlay);
    targetOverlayEl = overlay;
    positionTargetOverlay(panel);

    const input = overlay.querySelector<HTMLInputElement>(".bp-lock-input")!;
    const button = overlay.querySelector<HTMLButtonElement>(".bp-lock-button")!;
    const errorEl = overlay.querySelector<HTMLElement>(".bp-lock-error")!;

    const attemptUnlock = async () => {
        if (await verifyPin(input.value)) {
            sessionUnlockedKeys.add(activeKey!);
            removeTargetLockOverlay();
        } else {
            errorEl.style.display = "block";
            input.value = "";
            input.focus();
        }
    };
    button.addEventListener("click", attemptUnlock);
    input.addEventListener("keydown", e => { if (e.key === "Enter") attemptUnlock(); });

    targetOverlayKeyBlocker = (e: KeyboardEvent) => {
        if (!overlay.contains(e.target as Node)) { e.stopPropagation(); e.preventDefault(); }
    };
    document.addEventListener("keydown", targetOverlayKeyBlocker, true);
}

function positionTargetOverlay(panel: HTMLElement) {
    if (!targetOverlayEl) return;
    const rect = panel.getBoundingClientRect();
    Object.assign(targetOverlayEl.style, {
        position: "fixed", top: `${rect.top}px`, left: `${rect.left}px`,
        width: `${rect.width}px`, height: `${rect.height}px`,
    });
}
function removeTargetLockOverlay() {
    if (targetOverlayKeyBlocker) {
        document.removeEventListener("keydown", targetOverlayKeyBlocker, true);
        targetOverlayKeyBlocker = null;
    }
    targetOverlayEl?.remove();
    targetOverlayEl = null;
    targetOverlayLockKey = null;
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export const settings = definePluginSettings({
    enabled: { type: OptionType.BOOLEAN, description: "Master switch for BetterPrivacy", default: true, onChange: () => applyBodyFlags() },
    defaultMethod: {
        type: OptionType.SELECT,
        description: "How protected content is obscured",
        options: [
            { label: "Blur", value: "blur", default: true },
            { label: "Pixelate", value: "pixelate" },
            { label: "Hide", value: "hide" },
        ],
        onChange: () => updateFilterVar(),
    },
    blurStrength: {
        type: OptionType.SLIDER,
        description: "Blur strength (px)",
        markers: [2, 4, 8, 12, 16, 24],
        default: 8,
        stickToMarkers: false,
        onChange: () => updateFilterVar(),
    },

    // Profile
    hideDisplayNames: { type: OptionType.BOOLEAN, description: "Hide/blur display names", default: false, onChange: () => applyBodyFlags() },
    hideUsernames: { type: OptionType.BOOLEAN, description: "Hide/blur usernames (@handles)", default: false, onChange: () => applyBodyFlags() },
    hideUserIds: { type: OptionType.BOOLEAN, description: "Hide/blur user IDs", default: true },
    hideAvatars: { type: OptionType.BOOLEAN, description: "Hide/blur profile pictures", default: false, onChange: () => applyBodyFlags() },
    hideBadges: { type: OptionType.BOOLEAN, description: "Hide/blur badges", default: false, onChange: () => applyBodyFlags() },
    hideBio: { type: OptionType.BOOLEAN, description: "Hide/blur About Me / bio text", default: false, onChange: () => applyBodyFlags() },
    hideJoinDate: { type: OptionType.BOOLEAN, description: "Hide/blur join/friend date info", default: false, onChange: () => applyBodyFlags() },
    hideStatus: { type: OptionType.BOOLEAN, description: "Hide/blur online/idle/DND status", default: false },
    hideMutualFriends: { type: OptionType.BOOLEAN, description: "Hide mutual friends", default: false, onChange: () => applyBodyFlags() },
    hideMutualServers: { type: OptionType.BOOLEAN, description: "Hide mutual servers", default: false, onChange: () => applyBodyFlags() },
    hideRoles: { type: OptionType.BOOLEAN, description: "Hide/blur roles shown on profile", default: false },
    hideConnectedAccounts: { type: OptionType.BOOLEAN, description: "Hide connected account info", default: false },

    // Messages
    protectMessageContent: { type: OptionType.BOOLEAN, description: "Blur/hide message text", default: false, onChange: () => applyBodyFlags() },
    protectAttachments: { type: OptionType.BOOLEAN, description: "Blur/hide images, videos, files, embeds", default: false },
    protectReactions: { type: OptionType.BOOLEAN, description: "Blur/hide reactions", default: false },

    // Server
    hideServerNames: { type: OptionType.BOOLEAN, description: "Hide/blur server names", default: false, onChange: () => applyBodyFlags() },
    hideServerIcons: { type: OptionType.BOOLEAN, description: "Hide/blur server icons", default: false, onChange: () => applyBodyFlags() },
    hideMemberList: { type: OptionType.BOOLEAN, description: "Blur the member list sidebar", default: false, onChange: () => applyBodyFlags() },

    // Security
    autoLockMinutes: {
        type: OptionType.SLIDER,
        description: "Auto re-lock after N minutes of inactivity (0 = never)",
        markers: [0, 1, 5, 15, 30, 60], default: 0, stickToMarkers: true,
    },
    panicHotkeyEnabled: { type: OptionType.BOOLEAN, description: "Enable panic hotkey (Ctrl+Shift+P, works even when Discord isn't focused)", default: true },
    panicTargetMode: {
        type: OptionType.SELECT,
        description: "Mode the panic hotkey switches to. Your actual saved mode is restored when you toggle it off.",
        options: [
            { label: "Screenshot Mode", value: "screenshot" },
            { label: "Streamer Mode", value: "streamer" },
            { label: "Maximum Privacy", value: "maximum", default: true },
        ],
    },

    managePin: { type: OptionType.COMPONENT, description: "Set, change, or remove your PIN", component: () => <PinManager /> },
    manageProtectedEntities: { type: OptionType.COMPONENT, description: "Manage permanently protected users/servers", component: () => <ManageProtectedEntities /> },

    privacyMode: {
        type: OptionType.SELECT,
        description: "Active privacy mode",
        options: [
            { label: "Normal", value: "normal", default: true },
            { label: "Screenshot Mode", value: "screenshot" },
            { label: "Streamer Mode", value: "streamer" },
            { label: "Maximum Privacy", value: "maximum" },
            { label: "Custom (use the toggles above)", value: "custom" },
        ],
        onChange(value: PrivacyMode) { applyModeToDom(value); },
    },
});

// ---------------------------------------------------------------------------
// CSS-driven protection engine.
// ---------------------------------------------------------------------------

const CATEGORY_FLAGS = [
    "hideDisplayNames", "hideUsernames", "hideAvatars", "hideBadges", "hideBio",
    "hideJoinDate", "hideMemberList", "hideServerNames", "hideServerIcons",
    "protectMessageContent", "hideMutualFriends", "hideMutualServers",
] as const;

function applyBodyFlags() {
    const masterOn = settings.store.enabled;
    for (const key of CATEGORY_FLAGS) {
        const on = panicActive || (masterOn && !!settings.store[key]);
        document.body.classList.toggle(`bp-flag-${key}`, on);
    }
}

function updateFilterVar() {
    const strength = settings.store.blurStrength;
    const method = settings.store.defaultMethod;
    let px = strength;
    if (currentMode === "screenshot") px += 2;
    if (currentMode === "streamer") px += 4;
    if (currentMode === "maximum") px = 20;

    let filter: string;
    if (method === "pixelate") filter = `blur(${Math.max(3, px - 4)}px) contrast(1.6) saturate(0.3)`;
    else if (method === "hide") filter = `blur(${Math.max(px, 30)}px) brightness(0.3)`;
    else filter = `blur(${px}px)`;

    document.body.style.setProperty("--bp-filter", filter);
}

// Mutual Friends / Servers share one wrapper class; only the label text
// tells them apart, so this stays JS-driven (can't be a CSS selector).
function protectMutuals() {
    document.querySelectorAll<HTMLElement>('[class*="mutuals_"] [class*="section_"]').forEach(section => {
        const label = section.textContent || "";
        const isFriends = /friend/i.test(label);
        const isServers = /server/i.test(label);
        const on = panicActive || (settings.store.enabled &&
            ((isFriends && settings.store.hideMutualFriends) || (isServers && settings.store.hideMutualServers)));
        section.classList.toggle("bp-mutual-hit", on);
    });
}

// pls check that this work tobi
let entityStyleEl: HTMLStyleElement | null = null;

function updateEntityStyles() {
    if (!entityStyleEl) {
        entityStyleEl = document.createElement("style");
        document.head.appendChild(entityStyleEl);
    }
    const rules: string[] = [];
    for (const u of protectedUserCache) {
        if (u.fields.avatar) rules.push(`img[src*="/avatars/${u.id}/"]{filter:var(--bp-filter) !important;}`);
    }
    for (const s of protectedServerCache) {
        rules.push(`[data-list-item-id*="guildsnav___${s.id}"]{filter:var(--bp-filter) !important;}`);
    }
    entityStyleEl.textContent = rules.join("\n");
}

function protectEntityTextMatches() {
    for (const u of protectedUserCache) {
        if (u.fields.username && u.username) {
            document.querySelectorAll<HTMLElement>(
                '[class*="username_"], a[href^="/channels/@me/"] [class*="overflowTooltip"]'
            ).forEach(el => el.classList.toggle("bp-entity-hit", el.textContent?.trim() === u.username));
        }
        if (u.fields.messages) {
            document.querySelectorAll<HTMLImageElement>(`img[src*="/avatars/${u.id}/"]`).forEach(avatarEl => {
                let ancestor: HTMLElement | null = avatarEl.parentElement;
                for (let i = 0; i < 6 && ancestor; i++) {
                    const contents = ancestor.querySelectorAll<HTMLElement>('[id^="message-content-"]');
                    if (contents.length > 0) {
                        contents.forEach(c => c.classList.add("bp-entity-hit"));
                        break;
                    }
                    ancestor = ancestor.parentElement;
                }
            });
        }
    }
}

function runDynamicScans() {
    protectMutuals();
    protectEntityTextMatches();
}

function startObserver() {
    applyBodyFlags();
    updateFilterVar();
    updateEntityStyles();
    runDynamicScans();
    updateTargetLockOverlay();

    mutationObserver = new MutationObserver(mutations => {
        for (const m of mutations) {
            if (m.addedNodes.length > 0) {
                runDynamicScans();
                updateTargetLockOverlay();
                break;
            }
        }
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });
}

function stopObserver() {
    mutationObserver?.disconnect();
    mutationObserver = null;
    document.querySelectorAll(".bp-mutual-hit, .bp-entity-hit").forEach(el => el.classList.remove("bp-mutual-hit", "bp-entity-hit"));
    entityStyleEl?.remove();
    entityStyleEl = null;
    removeTargetLockOverlay();
}

// ---------------------------------------------------------------------------
// Panic hotkey
// ---------------------------------------------------------------------------

function goToFriendsTab() {
    document.querySelector<HTMLElement>('[aria-label="Friends"]')?.click();
}

function togglePanic() {
    if (!panicActive) {
        panicPreviousMode = currentMode;
        panicActive = true;
        applyModeToDom(settings.store.panicTargetMode as PrivacyMode);
    } else {
        panicActive = false;
        applyModeToDom(panicPreviousMode ?? (settings.store.privacyMode as PrivacyMode));
        panicPreviousMode = null;
    }
    applyBodyFlags();
    runDynamicScans();
    goToFriendsTab();
}

// Guards against a double-trigger if both the OS-level global shortcut and
// the local focused-window listener fire for the same keypress.
let lastPanicTrigger = 0;
function togglePanicDebounced() {
    const now = Date.now();
    if (now - lastPanicTrigger < 400) return;
    lastPanicTrigger = now;
    togglePanic();
}

let globalPanicEventListener: (() => void) | null = null;

function registerHotkey() {
    // True global hotkey (works unfocused). see native.ts.
    try {
        (window as any).VencordNative?.pluginHelpers?.BetterPrivacy?.registerGlobalPanicHotkey?.();
    } catch (e) {
        console.error("[BetterPrivacy] Could not reach native module:", e);
    }

    globalPanicEventListener = () => {
        if (settings.store.panicHotkeyEnabled) togglePanicDebounced();
    };
    window.addEventListener("BetterPrivacy-panic", globalPanicEventListener);

    // Local fallback for when Discord is focused, in case native registration failed.
    hotkeyListener = (e: KeyboardEvent) => {
        if (!settings.store.panicHotkeyEnabled) return;
        if (e.ctrlKey && e.shiftKey && e.key.toUpperCase() === "P") {
            e.preventDefault();
            togglePanicDebounced();
        }
    };
    window.addEventListener("keydown", hotkeyListener, true);
}

function unregisterHotkey() {
    try {
        (window as any).VencordNative?.pluginHelpers?.BetterPrivacy?.unregisterGlobalPanicHotkey?.();
    } catch { /* ignore */ }
    if (globalPanicEventListener) window.removeEventListener("BetterPrivacy-panic", globalPanicEventListener);
    globalPanicEventListener = null;
    if (hotkeyListener) window.removeEventListener("keydown", hotkeyListener, true);
    hotkeyListener = null;
}

// ---------------------------------------------------------------------------
// Context menus
// ---------------------------------------------------------------------------

const userContextPatch: NavContextMenuPatchCallback = (
    children,
    props: { user?: { id: string; username: string; }; channel?: { id: string; name: string; type: number; }; }
) => {
    const user = props?.user;
    if (!user) return;
    const entry = protectedUserCache.find(u => u.id === user.id);
    const fields = entry?.fields ?? EMPTY_USER_FIELDS;

    // Discord passes `channel` alongside `user` when opened from a DM (type 1) or group DM (type 3).
    const channel = props?.channel;
    const isDmLike = channel && (channel.type === 1 || channel.type === 3);
    const channelLocked = isDmLike ? isLocked("channel", channel.id) : false;

    children.push(
        <Menu.MenuGroup key="better-privacy-group">
            <Menu.MenuItem id="better-privacy-user" label="BetterPrivacy">
                <Menu.MenuCheckboxItem id="bp-user-avatar" label="Hide Avatar" checked={fields.avatar} action={() => toggleUserField(user.id, user.username, "avatar")} />
                <Menu.MenuCheckboxItem id="bp-user-username" label="Hide Username" checked={fields.username} action={() => toggleUserField(user.id, user.username, "username")} />
                <Menu.MenuCheckboxItem id="bp-user-messages" label="Hide Messages" checked={fields.messages} action={() => toggleUserField(user.id, user.username, "messages")} />
                {isDmLike && (
                    <>
                        <Menu.MenuSeparator />
                        <Menu.MenuItem
                            id="bp-user-lock-chat"
                            label={channelLocked ? "Unlock This Chat" : "Lock This Chat (PIN required)"}
                            action={() => toggleLockedTarget("channel", channel!.id, channel!.name || user.username)}
                        />
                    </>
                )}
            </Menu.MenuItem>
        </Menu.MenuGroup>
    );
};

const guildContextPatch: NavContextMenuPatchCallback = (children, props: { guild?: { id: string; name: string; }; }) => {
    const guild = props?.guild;
    if (!guild) return;
    const isProtected = protectedServerCache.some(s => s.id === guild.id);
    const isServerLocked = isLocked("guild", guild.id);
    children.push(
        <Menu.MenuGroup key="better-privacy-group">
            <Menu.MenuItem id="better-privacy-guild" label="BetterPrivacy">
                <Menu.MenuItem id="better-privacy-toggle-guild-protect" label={isProtected ? "Unprotect Server" : "Always Hide Server"} action={() => toggleProtectedServer(guild.id, guild.name)} />
                <Menu.MenuItem id="better-privacy-toggle-guild-lock" label={isServerLocked ? "Unlock This Server" : "Lock This Server (PIN required)"} action={() => toggleLockedTarget("guild", guild.id, guild.name)} />
            </Menu.MenuItem>
        </Menu.MenuGroup>
    );
};

const channelContextPatch: NavContextMenuPatchCallback = (children, props: { channel?: { id: string; name: string; }; }) => {
    const channel = props?.channel;
    if (!channel) return;
    const isChannelLockedNow = isLocked("channel", channel.id);
    children.push(
        <Menu.MenuGroup key="better-privacy-group">
            <Menu.MenuItem
                id="better-privacy-toggle-channel-lock"
                label={isChannelLockedNow ? "BetterPrivacy: Unlock Channel" : "BetterPrivacy: Lock Channel (PIN required)"}
                action={() => toggleLockedTarget("channel", channel.id, channel.name)}
            />
        </Menu.MenuGroup>
    );
};

// ---------------------------------------------------------------------------
// Settings UI components
// ---------------------------------------------------------------------------

function PinManager() {
    const [hasPin, setHasPin] = useState(false);
    const [pin, setPinValue] = useState("");
    const [confirmPin, setConfirmPin] = useState("");
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    useEffect(() => { hasPinConfigured().then(setHasPin); }, []);

    async function handleSet() {
        setError(""); setSuccess("");
        if (pin.length < 4) return setError("PIN must be at least 4 characters.");
        if (pin !== confirmPin) return setError("PINs don't match.");
        await setPin(pin);
        setPinValue(""); setConfirmPin(""); setHasPin(true);
        setSuccess("PIN set.");
    }

    async function handleRemove() {
        await DataStore.del(DS_PIN_HASH);
        await DataStore.del(DS_PIN_SALT);
        setHasPin(false);
        setSuccess("PIN removed.");
    }

    return (
        <Forms.FormSection>
            <Forms.FormText type="description" style={{ fontSize: "12px", marginBottom: 6 }}>
                {hasPin ? "A PIN is currently set." : "No PIN set yet."} Hashed locally, never leaves your device.
            </Forms.FormText>
            <div style={{ display: "flex", gap: "6px", marginBottom: 6 }}>
                <TextInput type="password" placeholder="New PIN" value={pin} onChange={setPinValue} style={{ flex: 1 }} />
                <TextInput type="password" placeholder="Confirm PIN" value={confirmPin} onChange={setConfirmPin} style={{ flex: 1 }} />
            </div>
            <div style={{ display: "flex", gap: "6px" }}>
                <Button size={Button.Sizes.SMALL} onClick={handleSet}>{hasPin ? "Change PIN" : "Set PIN"}</Button>
                {hasPin && <Button size={Button.Sizes.SMALL} color={Button.Colors.RED} onClick={handleRemove}>Remove PIN</Button>}
            </div>
            {error && <Forms.FormText style={{ color: "var(--text-danger, #f23f42)", fontSize: "12px", marginTop: 4 }}>{error}</Forms.FormText>}
            {success && <Forms.FormText style={{ color: "var(--text-positive, #23a55a)", fontSize: "12px", marginTop: 4 }}>{success}</Forms.FormText>}
        </Forms.FormSection>
    );
}

function ManageProtectedEntities() {
    const [users, setUsers] = useState<ProtectedUser[]>(protectedUserCache);
    const [guilds, setGuilds] = useState<ProtectedServer[]>(protectedServerCache);

    useEffect(() => {
        getProtectedUsers().then(setUsers);
        getProtectedServers().then(setGuilds);
    }, []);

    async function setField(id: string, username: string, field: keyof ProtectedUserFields) {
        await toggleUserField(id, username, field);
        setUsers(await getProtectedUsers());
    }
    async function removeUser(id: string) {
        const list = users.filter(u => u.id !== id);
        await DataStore.set(DS_PROTECTED_USERS, list);
        protectedUserCache = list;
        setUsers(list);
        updateEntityStyles();
    }
    async function removeGuild(id: string) {
        const list = guilds.filter(s => s.id !== id);
        await DataStore.set(DS_PROTECTED_SERVERS, list);
        protectedServerCache = list;
        setGuilds(list);
        updateEntityStyles();
    }

    const rowStyle = { display: "flex", alignItems: "center", gap: "8px", padding: "3px 0", fontSize: "13px" } as const;
    const chipStyle = (active: boolean) => ({
        fontSize: "11px", padding: "1px 6px", borderRadius: "4px", cursor: "pointer", userSelect: "none",
        background: active ? "var(--brand-500, #5865f2)" : "var(--background-modifier-accent, #4e5058)",
        color: active ? "#fff" : "var(--text-muted, #949ba4)",
    } as const);

    return (
        <Forms.FormSection>
            <Forms.FormTitle tag="h5" style={{ marginBottom: 4 }}>Protected Users</Forms.FormTitle>
            {users.length === 0 && <Forms.FormText type="description" style={{ fontSize: "12px" }}>Right-click a user → BetterPrivacy to add one.</Forms.FormText>}
            {users.map(u => (
                <div key={u.id} style={rowStyle}>
                    <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.username}</span>
                    <span style={chipStyle(u.fields.avatar)} onClick={() => setField(u.id, u.username, "avatar")}>avatar</span>
                    <span style={chipStyle(u.fields.username)} onClick={() => setField(u.id, u.username, "username")}>name</span>
                    <span style={chipStyle(u.fields.messages)} onClick={() => setField(u.id, u.username, "messages")}>msgs</span>
                    <Button size={Button.Sizes.MIN} color={Button.Colors.RED} onClick={() => removeUser(u.id)}>✕</Button>
                </div>
            ))}
            <Forms.FormDivider style={{ margin: "8px 0" }} />
            <Forms.FormTitle tag="h5" style={{ marginBottom: 4 }}>Protected Servers</Forms.FormTitle>
            {guilds.length === 0 && <Forms.FormText type="description" style={{ fontSize: "12px" }}>Right-click a server icon → BetterPrivacy to add one.</Forms.FormText>}
            {guilds.map(s => (
                <div key={s.id} style={rowStyle}>
                    <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.name}</span>
                    <Button size={Button.Sizes.MIN} color={Button.Colors.RED} onClick={() => removeGuild(s.id)}>✕</Button>
                </div>
            ))}
        </Forms.FormSection>
    );
}

// ---------------------------------------------------------------------------
// Plugin definition
// ---------------------------------------------------------------------------

export default definePlugin({
    name: "BetterPrivacy",
    description: "Client-side visual privacy & screen-protection toolkit: blur/hide/lock profiles, messages, servers and DMs.",
    authors: [{ name: "TobiasKeu", id: 894574168232828971n }],
    settings,

    async start() {
        applyModeToDom(settings.store.privacyMode as PrivacyMode);

        protectedUserCache = await getProtectedUsers();
        protectedServerCache = await getProtectedServers();
        lockedTargetCache = await getLockedTargets();

        addContextMenuPatch("user-context", userContextPatch);
        addContextMenuPatch("guild-context", guildContextPatch);
        addContextMenuPatch("channel-context", channelContextPatch);

        FluxDispatcher.subscribe("CHANNEL_SELECT", updateTargetLockOverlay);

        startObserver();
        registerHotkey();
    },

    stop() {
        stopObserver();
        unregisterHotkey();
        FluxDispatcher.unsubscribe("CHANNEL_SELECT", updateTargetLockOverlay);
        removeContextMenuPatch("user-context", userContextPatch);
        removeContextMenuPatch("guild-context", guildContextPatch);
        removeContextMenuPatch("channel-context", channelContextPatch);
        document.body.classList.remove(...ALL_MODE_CLASSES, ...CATEGORY_FLAGS.map(f => `bp-flag-${f}`));
    },

    api: {
        setPin, verifyPin, hasPinConfigured, applyModeToDom,
        get currentMode() { return currentMode; },
    },
});
