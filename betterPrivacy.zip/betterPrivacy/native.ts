import { BrowserWindow, globalShortcut } from "electron";

const ACCELERATOR = "CommandOrControl+Shift+P";
let isRegistered = false;

export function registerGlobalPanicHotkey() {
    if (isRegistered) return;
    try {
        const ok = globalShortcut.register(ACCELERATOR, () => {
            for (const win of BrowserWindow.getAllWindows()) {
                // We can't easily push a custom IPC event to an arbitrary
                // userplugin's renderer code without deeper Vencord IPC
                // wiring, so instead we just execute a tiny snippet directly
                // in the page that dispatches a normal DOM CustomEvent —
                // index.tsx listens for this exact event name.
                win.webContents
                    .executeJavaScript(
                        `window.dispatchEvent(new CustomEvent("BetterPrivacy-panic"));`
                    )
                    .catch(() => {
                        // Window may not have finished loading, or may not
                        // be the Discord window (e.g. a devtools window) —
                        // safe to ignore.
                    });
            }
        });
        isRegistered = ok;
        if (!ok) {
            console.error(
                `[BetterPrivacy] Could not register global hotkey ${ACCELERATOR} — it may already be in use by another application.`
            );
        }
    } catch (e) {
        console.error("[BetterPrivacy] Failed to register global hotkey:", e);
    }
}

export function unregisterGlobalPanicHotkey() {
    if (!isRegistered) return;
    globalShortcut.unregister(ACCELERATOR);
    isRegistered = false;
}
